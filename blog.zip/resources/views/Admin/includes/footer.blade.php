<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <!--<b>Version</b> 2.4.0 -->
    </div>
    <strong>Copyright &copy; 2019-2020. All rights
    reserved.
  </footer>

