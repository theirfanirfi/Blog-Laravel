<?php /* C:\xampp\htdocs\Blog-Laravel\resources\views/Frontend/singleblog.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<style>

.tags {
  list-style: none;
  margin: 0;
  overflow: hidden;
  padding: 0;
}

.tags li {
  float: left;
}

.tag {
  background: #eee;
  border-radius: 3px 0 0 3px;
  color: #999;
  display: inline-block;
  height: 26px;
  line-height: 26px;
  padding: 0 20px 0 23px;
  position: relative;
  margin: 0 10px 10px 0;
  text-decoration: none;
  -webkit-transition: color 0.2s;
}

.tag::before {
  background: #fff;
  border-radius: 10px;
  box-shadow: inset 0 1px rgba(0, 0, 0, 0.25);
  content: '';
  height: 6px;
  left: 10px;
  position: absolute;
  width: 6px;
  top: 10px;
}

.tag::after {
  background: #fff;
  border-bottom: 13px solid transparent;
  border-left: 10px solid #eee;
  border-top: 13px solid transparent;
  content: '';
  position: absolute;
  right: 0;
  top: 0;
}

.tag:hover {
  background-color: crimson;
  color: white;
}

.tag:hover::after {
   border-left-color: crimson;
}

</style>
<!-- Main Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">

<div class="post-preview">
        <a href="post.html">
          <h2 class="post-title">
          </h2>
          <h3 class="post-subtitle">
          </h3>
        </a>
        <?php if(!empty($b->blog_image)): ?>
        <img src="<?php echo e(URL::asset('images/')); ?>/<?php echo e($b->blog_image); ?>" class="img-responsive img-thumbnail" style="width:100%; height:300px;" />
        <?php endif; ?>
        <p style="word-break: break-all;">
         <?php echo $b->blog_description; ?>

        </p>
        <p class="post-meta">Posted by
          <a href="#"><?php echo e($b->getAuthor()); ?></a>
          on <?php echo e($b->updated_at); ?></p>

          <p class="post-meta" style="">Category
                <a href="<?php echo e(route('blogsbycategory',['id' => $b->cat_id])); ?>"><?php echo e($b->getBlogCategory()); ?></a>
               </p>
      </div>

      <?php $exploded = explode(",",$b->tags); ?>
      <p  style="font-size:12px;margin:0px;">Tags:</p>
      <ul class="tags">
          <?php $__currentLoopData = $exploded; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><a href="#" class="tag" style="font-size:12px;"><?php echo e($e); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>


          <!-- keywords -->

          <?php $exploded = explode(",",$b->keywords); ?>
          <p  style="font-size:12px;margin:0px;">Keywords:</p>
          <ul class="tags">
              <?php $__currentLoopData = $exploded; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a href="#" class="tag" style="font-size:12px;"><?php echo e($e); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
      <hr>

      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Frontend._Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>