<?php /* C:\xampp\htdocs\Blog-Laravel\resources\views/Frontend/contact.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<!-- Main Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">
<?php echo $contact->contact_description; ?>

      </div>
      <div class="col-lg-2 col-md-2 mx-auto">
          <h6>Categories</h6>
        <ul>
            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <p> <li style="list-style-type: none;font-size:14px;"><a href="<?php echo e(route('blogsbycategory',['id' => $c->cat_id])); ?>"> <?php echo e($c->cat_title); ?> </a></li>
           </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Frontend._Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>