<?php /* C:\xampp\htdocs\Blog-Laravel\resources\views/Frontend/home.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<!-- Main Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-10 mx-auto">

<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="post-preview">
        <a href="<?php echo e(route('blog',['id' => $b->id])); ?>">
          <h2 class="post-title">
           <?php echo e($b->blog_title); ?>

          </h2>
          <h3 class="post-subtitle">

          </h3>
        </a>

        <?php if(!empty($b->blog_image)): ?>
        <img src="<?php echo e(URL::asset('images/')); ?>/<?php echo e($b->blog_image); ?>" class="img-responsive img-thumbnail" style="width:100%; height:300px;" />
        <?php endif; ?>

        <?php if(!empty($b->blog_excerpt)){ ?>

            <?php echo e($b->blog_excerpt); ?>

           <?php } else {

               echo substr($b->blog_description,0,300). " ...";
            } ?>
            <br/>
        <a class="btn-sm btn-info" style="color:white;" href="<?php echo e(route('blog',['id' => $b->id])); ?>">Read more</a>
        <p class="post-meta">Posted by
          <a href="#"><?php echo e($b->getAuthor()); ?></a>
          on <?php echo e($b->updated_at); ?></p>
      </div>
      <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
      <div class="col-lg-2 col-md-2 mx-auto">
          <h6>Categories</h6>
        <ul>
            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <p> <li style="list-style-type: none;font-size:14px;"><a href="<?php echo e(route('blogsbycategory',['id' => $c->cat_id])); ?>"> <?php echo e($c->cat_title); ?> </a></li>
           </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('Frontend._Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>