<?php /* C:\xampp\htdocs\Blog-Laravel\resources\views/Admin/catblogs.blade.php */ ?>
  
  <?php $__env->startSection('content'); ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Blogs
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
    <?php echo $__env->make('Admin.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<!-- users -->

<div class="box">
        <div class="box-header">
          <h3 class="box-title"><?php echo e($cat->cat_title); ?> 's Blogs</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
                    <tr>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Published on</th>
                            <th>Action</th>
                          </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                        <td><a href="<?php echo e(route('editblog',['id' => $b->id])); ?>"><?php echo e($b->blog_title); ?></a></td>
                        <td><?php echo e($b->getBlogCategory()); ?></td>
                        <td><?php echo e($b->created_at); ?></td>
                        <?php if($user->role == 1): ?>
                        <td><a href="<?php echo e(route('editblog',['id' => $b->id])); ?>"><i class="fa fa-pencil"></i></a> | <a href="<?php echo e(route('deleteblog',['id' => $b->id])); ?>"><i class="fa fa-trash"></i></a></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </tbody>
            <tfoot>
            <tr>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Published on</th>
                    <th>Action</th>
            </tr>
            </tfoot>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>