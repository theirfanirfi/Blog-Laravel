<?php /* C:\xampp\htdocs\Blog-Laravel\resources\views/Admin/aboutus.blade.php */ ?>
  
  <?php $__env->startSection('content'); ?>
  <link rel="stylesheet" href="<?php echo e(URL::asset('plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')); ?>">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
            <?php echo $__env->make('Admin.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


      <div class="box">
            <div class="box-header">
              <h3 class="box-title">About Us Page Description</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <form action="<?php echo e(route('saveabout')); ?>" method="POST">
                    <textarea name="about_description" class="textarea" placeholder="Place some text here"
                    style="width: 100%; height: 300px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">
                <?php if(!empty($about->about_description)){ echo $about->about_description; } ?>
                </textarea>
                    <?php echo csrf_field(); ?>
                    <div class="form-group pull-right">
                            <button type="submit" name="save" class="btn btn-primary">Save Changes</button>
                                       </div>
                </form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


  <?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>