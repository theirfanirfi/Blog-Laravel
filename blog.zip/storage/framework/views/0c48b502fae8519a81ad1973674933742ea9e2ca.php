<?php /* C:\xampp\htdocs\Blog-Laravel\resources\views/Admin/includes/alert.blade.php */ ?>
<?php if(Session('error')): ?>
<div class="alert alert-danger alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-ban"></i> Error</h4>
    <?php echo e(Session('error')); ?>

  </div>
  <?php endif; ?>

  <?php if(Session('success')): ?>
<div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-check"></i> Success</h4>
    <?php echo e(Session('success')); ?>

  </div>
  <?php endif; ?>

<?php
  if(Session('messages')){
    $messages = Session('messages');
    if(!empty($messages['error'])){
?>
    <div class="alert alert-danger alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-ban"></i> Error</h4>
    <?php echo $messages['error']; ?>
  </div>
<?php }
 if(!empty($messages['success'])){
?>

  <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-check"></i> Success</h4>
        <?php echo $messages['success']; ?>
      </div>
<?php
  }
}
?>
